import { legacy_createStore as createStore, combineReducers, applyMiddleware, compose} from 'redux';
import thunk from 'redux-thunk';
import { createLogger } from 'redux-logger';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

const rootReducer = combineReducers({});

const persistConfig = {
  key: 'root',
  storage: storage,
};
const middleware=[thunk, createLogger()];
const composeEnhancers = compose;
const enhancer = composeEnhancers(
  applyMiddleware(...middleware),
);
const persistedReducer = persistReducer(persistConfig, rootReducer)
const store = createStore(
    persistedReducer,
    enhancer
  );
const persistor = persistStore(store);
export { persistor, store };