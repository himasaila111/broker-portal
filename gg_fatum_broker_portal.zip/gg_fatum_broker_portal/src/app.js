import "./app.css";
import { BrowserRouter, Routes, Route, Navigate} from "react-router-dom";
import LogIn from "./containers/auth/logIn/index";
import Dashboard from "./containers/home/dashboard/index";
import Clients from "./containers/home/clients/index";
import Products from "./containers/home/products/index";
import Policies from "./containers/home/policies/index";
import Coupons from "./containers/home/coupons/index";
import Content from "./containers/home/content/index";
import Partners from "./containers/home/partners/index";
import Analytics from "./containers/home/analytics/index";
import routes from "./utils/routes.json";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path={routes.logIn} element={<LogIn />} />
      <Route path={routes.index} element={ <Navigate to={routes.dashboard} /> }/>
        <Route path={routes.dashboard} element={<Dashboard />}></Route>
        <Route path={routes.clients} element={<Clients />}></Route>
        <Route path={routes.products} element={<Products />}></Route>
        <Route path={routes.policies} element={<Policies />}></Route>
        <Route path={routes.coupons} element={<Coupons />}></Route>
        <Route path={routes.content} element={<Content />}></Route>
        <Route path={routes.partners} element={<Partners />}></Route>
        <Route path={routes.analytics} element={<Analytics />}></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
