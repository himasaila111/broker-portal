import React from "react";
import { Box, AppBar, Toolbar, Button } from "@mui/material";
import { useNavigate, useLocation } from "react-router-dom";

    const clickedButtonStyle = {
        color: 'white !important',
        padding: "0px 12px",
        fontSize: "18px",
        fontWeight: "500",
        textTransform: "none",
        fontFamily: "'Nunito Sans', sans-serif",
        alignItems: "center",
        lineHeight: "60px",
        borderRadius: "0px",
        opacity: 1,
        boxShadow: "0 4px white",
    };

    const disabledButtonStyle = {
        ...clickedButtonStyle,
        opacity:0.25,
        boxShadow: "none",
        "&:hover": {
            opacity: 0.5,
            boxShadow: "0 4px rgba(255, 255, 255, 0.5)"
        }
    };


export default function Navbar() {
    const navigate = useNavigate();
    const location = useLocation();
    const navElements = ["Dashboard", "Clients", "Products", "Policies", "Coupons", "Content", "Partners", "Analytics"]

    const navigateEvent = (e) => {
        let route = e.target.innerText.toLowerCase();
        navigate("/" + route)
    }

    return (
        <Box>
            <AppBar position="static" style={{ background: '#2b2178' }}>
                <Toolbar>
                    {navElements.map((element) => {
                        return <Button onClick={navigateEvent} sx={location.pathname === "/" + element.toLowerCase() ? clickedButtonStyle  : disabledButtonStyle}>{element}</Button>
                    })}
                </Toolbar>
            </AppBar>
        </Box>
    )
}