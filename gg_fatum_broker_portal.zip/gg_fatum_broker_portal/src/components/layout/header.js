import React from "react";
import { Box, Typography, Button, Modal, CardMedia } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { makeStyles } from "@mui/styles";
import ClearIcon from '@mui/icons-material/Clear';
import LaunchIcon from '@mui/icons-material/Launch';
import LogoutIcon from '@mui/icons-material/Logout';
import userIcon from "../../assets/images/userOutline.svg";
import usFlag from "../../assets/images/flag-en.svg";
import dutchFlag from "../../assets/images/flag-nl.svg";

const useStyles = makeStyles({
    boxStyle: {
        height: "60px",
        background: "rgb(50, 38, 140)",
        paddingLeft:"20px",
        color: "white",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
    },
    navButtonStyle: {
        height: "60px",
        display: "flex",
        alignItems: "center",
        borderLeft: "1px solid rgba(255,255,255,.06)",
        cursor: "pointer",
        "&:hover": {
            background: "#ffffff1a",
        },
        padding:"0 16px"
    },
    titleStyle: {
        display: "flex",
        justifyContent: "space-between",

    },
    languageBodyStyle: {
        display: "flex",
        padding: "20px 0",
        borderTop: "1px solid #c4c4c4 !important",
        borderBottom: "1px solid #c4c4c4 !important",
        height: "35px",
        alignItems: "center",
    },
    languageButtonStyle: {
        width: "50%",
        padding: "17px 20px",
        background: "none",
        "&:hover": {
            background: "none",
        },
        cursor: "pointer",
    },
    closeButtonStyle: {
        textAlign: "center !important",
        margin: "20px 20px 15px auto",
        border: "1px solid #c4c4c4",
        width: "64px",
        borderRadius: "4px",
        "&:hover": {
            background: "none",
        },
    },
    userDetailsStyles:{
        display: "flex", 
        flexDirection: "column",
        textAlign:"left",

    }
})

const popUpModalStyle = {
    width: "600px",
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    display: "flex",
    flexDirection: "column",
    borderRadius: "4px",
    background: 'white',
};

const languageImageStyle = {
    width: "24px",
    height: "18px",
    marginRight: "10px",
}

const userAvatarStyle = {
    width: "34px",
    height: "34px",
    borderRadius: "50%",
    border: "2px solid #a2a9ba",
    marginRight: "8px",
}

const closeButtonStyle = {
    color: "#a2a9ba",
    width: "25px",
    margin: "10px",
    height: "30px",
    "&:hover": {
        background: "#efefef",
    },
}

const LaunchIconStyle = {
    color:"#c1c7d0",
    marginLeft:"8px",
}

export default function Header() {
    const theme = useTheme();
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    theme.typography.h1 = {
        fontSize: '18px',
        fontWeight: 800,
        fontFamily: "'Nunito Sans', sans-serif",
    };
    theme.typography.h2 = {
        fontSize: '20px',
        fontWeight: 500,
        fontFamily: "'Nunito Sans', sans-serif",
        padding: "10px 20px",
    };

    theme.typography.h3 = {
        fontSize: '16px',
        fontWeight: 400,
        fontFamily: "'Nunito Sans', sans-serif",
        textTransform: "none"
    };

    return (
        <Box className={classes.boxStyle}>
            <Typography variant="h1">Guardian Group</Typography>
            <Box display={"inline-flex"}>
                <Box className={classes.navButtonStyle}>
                    <Button type="button" sx={{padding:"0px !important", minWidth:"0px"}} onClick={handleOpen}>
                        <img width="24" height="18" src={usFlag} alt="en"/>
                    </Button>
                    <Modal
                        open={open}
                        onClose={handleClose}
                        aria-labelledby="modal-modal-title"
                        aria-describedby="modal-modal-description"
                    >
                        <Box sx={popUpModalStyle}>
                            <Box className={classes.titleStyle}>
                                <Typography variant="h2">
                                    Choose your language
                                </Typography>
                                <Button sx={closeButtonStyle} onClick={handleClose}>
                                    <ClearIcon />
                                </Button>
                            </Box>
                            <Box className={classes.languageBodyStyle}>
                                <Box className={classes.languageButtonStyle} sx={{ borderRight: "1px solid #c4c4c4" }}>
                                    <Button type="button">
                                        <CardMedia component="img" src={usFlag} alt="en" sx={languageImageStyle} />
                                        <Typography variant="h3" color={"black"}>
                                            English (English)
                                        </Typography>
                                    </Button>
                                </Box>
                                <Box className={classes.languageButtonStyle}>
                                    <Button type="button">
                                        <CardMedia component="img" src={dutchFlag} alt="nl" sx={languageImageStyle} />
                                        <Typography variant="h3" color={"black"}>
                                            Dutch (Dutch)
                                        </Typography>
                                    </Button>
                                </Box>
                            </Box>
                            <Box className={classes.closeButtonStyle}>
                                <Button type="button" onClick={handleClose}>
                                    <Typography variant="h3" color={"black"}>Close</Typography>
                                </Button>
                            </Box>
                        </Box>
                    </Modal>
                </Box>
                <Box className={classes.navButtonStyle}>
                    <Button type="button" sx={{padding:"0px"}}>
                        <CardMedia component="img" src={userIcon} alt="user" sx={userAvatarStyle} />
                        <Box className={classes.userDetailsStyles}>
                            <Typography variant="h3" color={"white"} marginBottom={"-5px"}>Hima Saila</Typography>
                            <Typography variant="h3" color={"#a29ccb"}>Super administrator</Typography>
                        </Box>
                        <LaunchIcon sx={LaunchIconStyle}/>
                    </Button>
                </Box>
                <Box className={classes.navButtonStyle}>
                <Typography variant="h3" color={"white"}>Log out</Typography>
                <LogoutIcon sx={LaunchIconStyle}/>
                </Box>
            </Box>
        </Box>
    )
}