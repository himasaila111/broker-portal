module.exports={
    required:"This field is required.",
    email: "The field does not match a valid email address.",
}