import React from "react";
import { makeStyles } from "@mui/styles";
import { useNavigate } from "react-router-dom";
import {
    Grid,
    Box,
    Paper,
    TextField,
    Typography,
    Button,
    IconButton,
    InputAdornment,
    Link,
    CardMedia,
    FormHelperText
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import LockIcon from '@mui/icons-material/Lock';
import { useForm } from 'react-hook-form';
import GGLogo from "../../../assets/images/logo.svg";
import usFlag from "../../../assets/images/flag-en.svg";
import messages from "./messages";
import { copyRightStyle, welcomeTitle, ggTitle, textFieldStyles, menuButtonStyle } from './style';

const useStyles = makeStyles({
    boxStyle: {
        padding: '40px 20px',
        margin: '0px 30px',
        display: "flex",
        flexDirection: "column",
        alignItems: "left",
    },
    boxStyle2: {
        width: "75%",
        padding: "100px",
        display: "flex",
        flexDirection: "column",
        alignItems: "left",
        flexWrap: "nowrap",
        color: "#fff",
    },

    logoStyle: {
        height: 80,
        width: 180,
        marginBottom: "20px"
    },

    backgroundStyle: {
        backgroundColor: '#4A4192',
        height: '100%',
    },
    labelStyle: {
        marginBottom: '4px',
        color: '#909090',
        fontSize: '18px',
    },
    iconStyle: {
        color: '#32268C',
        display: 'flex',
        flexDirection: 'row',
        margin: '3px 0 50px 0',
    },
    linkStyle: {
        color: '#32268C !important',
    },
    buttonStyle: {
        alignItems: "left",
        height: '55px',
        width: '210px',
        padding: '0 18px !important',
        background: '#32268c linear-gradient(198deg,#9d0059 0%,#32268c 100%)',
        border: 'none',
        color: 'white !important',
        textTransform: 'none !important',
        fontWeight: '500 !important',
        fontSize: '18px !important',
        fontFamily: "'Nunito Sans', sans-serif !important",
        marginBottom: "30px !important",
        "&:hover": {
            background: '#32268c linear-gradient(198deg,#86004c 0%,#281f70 100%)',
        }
    },
    errorStyle:{
            textAlign: 'left',
            margin: "-15px 0 15px !important",
            fontFamily: "'Nunito Sans', sans-serif !important",
            fontSize:"17px",
    }
});


export default function LogIn() {
    const classes = useStyles();
    const theme = useTheme();
    const navigate = useNavigate();
    const [showPassword, setShowPassword] = React.useState(false);
    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const initialValues = {
        email: "",
        password: "",
    };

    const {
        handleSubmit,
        register,
        formState: { errors },
    } = useForm({
        defaultValues: { ...initialValues },
    });

    const onSubmit = (values) => {
        console.log("submitted", values);
        navigate("/dashboard")
    };

    theme.typography.h1 = {
        fontSize: '36px',
        fontWeight: 800,
        fontFamily: "'Merriweather Sans', 'sans-serif'",
    };
    theme.typography.h2 = {
        fontSize: '18px',
        fontWeight: 700,
        color: "#909090",
    };

    return (
        <>
            <Grid
                container
                sx={{ height: "100vh" }}
            >
                <Grid
                    item
                    xs={12}
                    sm={12}
                    md={4}
                    elevation={0}
                    component={Paper}
                >
                    <Box className={classes.boxStyle}>
                        <Box
                            component="img"
                            className={classes.logoStyle}
                            alt="Gaurdian Group Logo"
                            src={GGLogo}
                        />

                        <Typography variant="h1" marginY={"10px"}>
                            Hi, welcome back!
                        </Typography>
                        <Typography variant="h2" marginBottom={"30px"}>
                            Please enter your login credentials to proceed to your dashboard.
                        </Typography>
                        <form noValidate onSubmit={handleSubmit(onSubmit)}>
                            <label className={classes.labelStyle}>Email</label>
                            <TextField
                                {...register("email", {
                                    required: messages.required,
                                    pattern: {
                                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
                                        message: messages.email
                                    }
                                })}
                                required
                                fullWidth
                                autoFocus
                                placeholder="E.g. info@mygaurdiangroup.com"
                                name="email"
                                type="email"
                                sx={textFieldStyles}
                            />

                            {errors.email && (
                                <FormHelperText
                                    error={!!errors?.email}
                                    className={classes.errorStyle}
                                >
                                    {errors?.email?.message}
                                </FormHelperText>
                            )}

                            <label className={classes.labelStyle}>Password</label>
                            <TextField
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton onClick={handleClickShowPassword} edge="end">
                                                {showPassword ? <Visibility /> : <VisibilityOff />}
                                            </IconButton>
                                        </InputAdornment>
                                    ),
                                }}
                                {...register("password", {
                                    required: messages.required,
                                })}
                                required
                                fullWidth
                                name="password"
                                placeholder="************"
                                type={showPassword ? "text" : "password"}
                                sx={textFieldStyles}
                            />

                            {errors.password && (
                                <FormHelperText
                                    error={!!errors?.password}
                                    className={classes.errorStyle}
                                >
                                    {errors?.password?.message}
                                </FormHelperText>
                            )}

                            <Box className={classes.iconStyle}>
                                <LockIcon />
                                <Link href="#" className={classes.linkStyle} underline="hover"><Typography variant="h2" marginLeft={"4px"} color='#32268C'>Forgot Password?</Typography></Link>
                            </Box>

                            <Button type="submit" className={classes.buttonStyle}>Sign in</Button>
                            <Typography variant="h2">If you choose to use the system you agree with the <Link href="#" className={classes.linkStyle} underline="none">Terms and conditions</Link> and <Link href="#" className={classes.linkStyle} underline="none"> Privacy policy</Link> of Guardian Group Fatum.</Typography>

                            <Button
                                aria-haspopup="true"
                                disableElevation
                                endIcon={<KeyboardArrowDownIcon />}
                                sx={menuButtonStyle}
                            >
                                <CardMedia component="img" image={usFlag} sx={{ height: "13px", width: "20px", marginRight: "20px" }} />
                                <Typography sx={{ fontSize: "20px", fontWeight: 300, marginRight: "60px", fontFamily: "'Nunito Sans', sans-serif", }}>English (English)</Typography>
                            </Button>

                            <Link sx={copyRightStyle} underline="none" href="#">© Guardian Group Fatum</Link>
                        </form>
                    </Box>
                </Grid>
                <Grid
                    item
                    md={8}
                    elevation={0}
                >
                    <Box className={classes.backgroundStyle}>
                        <Box className={classes.boxStyle2}>
                            <Typography sx={welcomeTitle}>Welcome to</Typography>
                            <Typography sx={ggTitle}>Guardian Group</Typography>
                        </Box>
                    </Box>
                </Grid>
            </Grid>
        </>
    )
}