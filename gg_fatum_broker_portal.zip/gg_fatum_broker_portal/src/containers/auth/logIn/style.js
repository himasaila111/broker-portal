export const copyRightStyle = {
    "&:visited": {
        color: "#909090",
    },
    "&:hover": {
        color: '#32268c',
        borderBottom: "1px solid #32268c",
    },
    borderBottom: "1px solid #909090",
    marginTop: "25px",
    width:"210px",
    fontSize: "18px",
    fontWeight: 700,
    display: "flex",
};

export const textFieldStyles = {
    backgroundColor: '#F7F7F7',
    marginTop: '0px',
    marginBottom: '20px',
    height: '55px',
    borderRadius: '5px',
    border: '1px solid #eaeaea',
    '& .MuiOutlinedInput-notchedOutline': {
        border: 'none'
    },
    input: {
        "&::placeholder": {
            opacity: 0.25,
        },
        fontWeight: 500,
        fontSize: '19px',
        fontFamily: "'Nunito Sans', sans-serif",
    },
};

export const welcomeTitle = {
    fontSize: '54px', 
    opacity: "0.5", 
    fontWeight: 300, 
    fontFamily: "'Merriweather Sans', 'sans-serif'"
}

export const ggTitle = {
    fontSize: '86px', 
    fontWeight: 800, 
    fontFamily: "'Merriweather Sans', 'sans-serif'"
}

export const menuButtonStyle = {
        marginTop: "20px",
        background: "#F7F7F7",
        border: '1px solid #eaeaea',
        '& .MuiOutlinedInput-notchedOutline': {
            border: 'none'
        },
        color: "#303030",
        fontSize: "20px",
        fontFamily: "'Nunito Sans', sans-serif",
        textTransform: "none",
        height: "55px",
}