import React from "react";
import Header from "../../../components/layout/header";
import Navbar from "../../../components/layout/navbar";

export default function Analytics() {
    return (
        <>
            <Header />
            <Navbar />
            hello i m analytics
        </>
    )
}