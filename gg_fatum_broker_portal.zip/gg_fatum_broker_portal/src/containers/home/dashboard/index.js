import React from "react";
import Header from "../../../components/layout/header";
import Navbar from "../../../components/layout/navbar";

export default function Dashboard() {
    return (
        <>
            <Header />
            <Navbar />
            hi i am dashboard
        </>
    )
}